<?php

for($i=0;$i<=255;$i++){
	$pdfCharWidths['courier'][chr($i)] = 600;
}
$pdfCharWidths['courierB'] = $pdfCharWidths['courier'];
$pdfCharWidths['courierI'] = $pdfCharWidths['courier'];
$pdfCharWidths['courierBI'] = $pdfCharWidths['courier'];
